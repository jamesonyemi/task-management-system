<?php

use Faker\Generator as Faker;

$factory->define(UserRoles::class, function (Faker $faker) {
    return [
        //
    ];
});
