<?php return array (
  'app' => 
  array (
    'name' => 'TMS',
    'subtitle' => 'TMS',
    'env' => 'production',
    'debug' => false,
    'ip' => 'ip',
    'url' => 'http://localhost/tms/public/',
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'key' => 'base64:oqd46gud414QY6cLCwX/7cwffgza6Ccps/zpdfXvsY4=',
    'cipher' => 'AES-256-CBC',
    'log' => 'single',
    'log_level' => 'debug',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Collective\\Html\\HtmlServiceProvider',
      23 => 'UxWeb\\SweetAlert\\SweetAlertServiceProvider',
      24 => 'Berkayk\\OneSignal\\OneSignalServiceProvider',
      25 => 'App\\Providers\\AppServiceProvider',
      26 => 'App\\Providers\\AuthServiceProvider',
      27 => 'App\\Providers\\EventServiceProvider',
      28 => 'App\\Providers\\RouteServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
      'SweetAlert' => 'UxWeb\\SweetAlert\\SweetAlert',
      'OneSignal' => 'Berkayk\\OneSignal\\OneSignalFacade',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
      ),
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '3725625987fdc35f9c3f',
        'secret' => '56a92f5bd25eedce6510',
        'app_id' => '414697',
        'options' => 
        array (
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\xampp\\htdocs\\tms\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
    ),
    'prefix' => 'tms_cache',
  ),
  'codegenerator' => 
  array (
    'template' => 'default',
    'templates_path' => 'resources/codegenerator-templates',
    'laravel_collective_templates' => 
    array (
      0 => 'default-collective',
    ),
    'files_upload_path' => 'uploads',
    'datetime_out_format' => 'm/d/Y H:i A',
    'fields_file_path' => 'resources/codegenerator-files',
    'migrations_path' => 'database/migrations',
    'form_requests_path' => 'Http/Requests',
    'controllers_path' => 'Http/Controllers',
    'models_path' => 'Models',
    'languages_path' => 'resources/lang',
    'default_mapper_file_name' => 'resources_map.json',
    'auto_manage_resource_mapper' => true,
    'common_header_patterns' => 
    array (
      0 => 'title',
      1 => 'name',
      2 => 'label',
      3 => 'header',
    ),
    'placeholder_by_html_type' => 
    array (
      'text' => 'Enter [% field_name %] here...',
      'number' => 'Enter [% field_name %] here...',
      'password' => 'Enter [% field_name %] here...',
      'email' => 'Enter [% field_name %] here...',
      'select' => 'Select [% field_name %]',
    ),
    'common_key_patterns' => 
    array (
      0 => '*_id',
      1 => '*_by',
    ),
    'common_definitions' => 
    array (
      0 => 
      array (
        'match' => 'id',
        'set' => 
        array (
          'is-on-form' => false,
          'is-on-index' => false,
          'is-on-show' => false,
          'html-type' => 'hidden',
          'data-type' => 'integer',
          'is-primary' => true,
          'is-auto-increment' => true,
          'is-nullable' => false,
          'is-unsigned' => true,
        ),
      ),
      1 => 
      array (
        'match' => 
        array (
          0 => 'title',
          1 => 'name',
          2 => 'label',
          3 => 'header',
        ),
        'set' => 
        array (
          'is-nullable' => false,
          'data-type' => 'string',
          'data-type-params' => 
          array (
            0 => 255,
          ),
        ),
      ),
      2 => 
      array (
        'match' => 
        array (
          0 => '*count*',
          1 => 'total*',
          2 => '*number*',
          3 => '*age*',
        ),
        'set' => 
        array (
          'html-type' => 'number',
        ),
      ),
      3 => 
      array (
        'match' => 
        array (
          0 => 'description*',
          1 => 'detail*',
          2 => 'note*',
          3 => 'message*',
        ),
        'set' => 
        array (
          'is-on-index' => false,
          'html-type' => 'textarea',
          'data-type-params' => 
          array (
            0 => 1000,
          ),
        ),
      ),
      4 => 
      array (
        'match' => 
        array (
          0 => 'picture',
          1 => 'file',
          2 => 'photo',
        ),
        'set' => 
        array (
          'is-on-index' => false,
          'html-type' => 'file',
        ),
      ),
      5 => 
      array (
        'match' => 
        array (
          0 => '*password*',
        ),
        'set' => 
        array (
          'html-type' => 'password',
        ),
      ),
      6 => 
      array (
        'match' => 
        array (
          0 => '*email*',
        ),
        'set' => 
        array (
          'html-type' => 'email',
        ),
      ),
      7 => 
      array (
        'match' => 
        array (
          0 => '*_id',
          1 => '*_by',
        ),
        'set' => 
        array (
          'data-type' => 'integer',
          'html-type' => 'select',
          'is-nullable' => false,
          'is-unsigned' => true,
          'is-index' => true,
        ),
      ),
      8 => 
      array (
        'match' => 
        array (
          0 => '*_at',
        ),
        'set' => 
        array (
          'data-type' => 'datetime',
        ),
      ),
      9 => 
      array (
        'match' => 
        array (
          0 => 'created_at',
          1 => 'updated_at',
          2 => 'deleted_at',
        ),
        'set' => 
        array (
          'data-type' => 'datetime',
          'is-on-form' => false,
          'is-on-index' => false,
          'is-on-show' => true,
        ),
      ),
      10 => 
      array (
        'match' => 
        array (
          0 => '*_date',
          1 => 'date_*',
        ),
        'set' => 
        array (
          'data-type' => 'date',
          'date-format' => 'm/d/Y',
        ),
      ),
      11 => 
      array (
        'match' => 
        array (
          0 => 'is_*',
          1 => 'has_*',
        ),
        'set' => 
        array (
          'data-type' => 'boolean',
          'html-type' => 'checkbox',
          'is-nullable' => false,
        ),
      ),
      12 => 
      array (
        'match' => 'created_by',
        'set' => 
        array (
          'title' => 'Creator',
          'data-type' => 'integer',
          'foreign-relation' => 
          array (
            'name' => 'creator',
            'type' => 'belongsTo',
            'params' => 
            array (
              0 => 'App\\User',
              1 => 'created_by',
            ),
            'field' => 'name',
          ),
          'on-store' => 'Illuminate\\Support\\Facades\\Auth::Id();',
        ),
      ),
      13 => 
      array (
        'match' => 
        array (
          0 => 'updated_by',
          1 => 'modified_by',
        ),
        'set' => 
        array (
          'title' => 'Updater',
          'data-type' => 'integer',
          'foreign-relation' => 
          array (
            'name' => 'updater',
            'type' => 'belongsTo',
            'params' => 
            array (
              0 => 'App\\User',
              1 => 'updated_by',
            ),
            'field' => 'name',
          ),
          'on-update' => 'Illuminate\\Support\\Facades\\Auth::Id();',
        ),
      ),
    ),
    'generic_view_labels' => 
    array (
      'create' => 
      array (
        'text' => 'Create New [% model_name_title %]',
        'template' => 'create_model',
      ),
      'delete' => 
      array (
        'text' => 'Delete [% model_name_title %]',
        'template' => 'delete_model',
        'in-function-with-collective' => true,
      ),
      'edit' => 
      array (
        'text' => 'Edit [% model_name_title %]',
        'template' => 'edit_model',
      ),
      'show' => 
      array (
        'text' => 'Show [% model_name_title %]',
        'template' => 'show_model',
      ),
      'show_all' => 
      array (
        'text' => 'Show All [% model_name_title %]',
        'template' => 'show_all_models',
      ),
      'add' => 
      array (
        'text' => 'Add',
        'template' => 'add',
        'in-function-with-collective' => true,
      ),
      'update' => 
      array (
        'text' => 'Update',
        'template' => 'update',
        'in-function-with-collective' => true,
      ),
      'confirm_delete' => 
      array (
        'text' => 'Delete [% model_name_title %]?',
        'template' => 'confirm_delete',
        'in-function-with-collective' => true,
      ),
      'none_available' => 
      array (
        'text' => 'No [% model_name_plural_title %] Available!',
        'template' => 'no_models_available',
      ),
      'model_plural' => 
      array (
        'text' => '[% model_name_plural_title %]',
        'template' => 'model_plural',
      ),
      'model_was_added' => 
      array (
        'text' => '[% model_name_title %] was successfully added!',
        'template' => 'model_was_added',
      ),
      'model_was_updated' => 
      array (
        'text' => '[% model_name_title %] was successfully updated!',
        'template' => 'model_was_updated',
      ),
      'model_was_deleted' => 
      array (
        'text' => '[% model_name_title %] was successfully deleted!',
        'template' => 'model_was_deleted',
      ),
      'unexpected_error' => 
      array (
        'text' => 'Unexpected error occurred while trying to process your request',
        'template' => 'unexpected_error',
      ),
    ),
    'eloquent_type_to_method' => 
    array (
      'char' => 'char',
      'date' => 'date',
      'datetime' => 'dateTime',
      'datetimetz' => 'dateTimeTz',
      'biginteger' => 'bigIncrements',
      'bigint' => 'bigIncrements',
      'blob' => 'binary',
      'binary' => 'binary',
      'bool' => 'boolean',
      'boolean' => 'boolean',
      'decimal' => 'decimal',
      'double' => 'double',
      'enum' => 'enum',
      'list' => 'enum',
      'float' => 'float',
      'int' => 'integer',
      'integer' => 'integer',
      'ipaddress' => 'ipAddress',
      'json' => 'json',
      'jsonb' => 'jsonb',
      'longtext' => 'longText',
      'macaddress' => 'macAddress',
      'mediuminteger' => 'mediumInteger',
      'mediumint' => 'mediumInteger',
      'mediumtext' => 'mediumText',
      'morphs' => 'morphs',
      'string' => 'string',
      'varchar' => 'string',
      'nvarchar' => 'string',
      'text' => 'text',
      'time' => 'time',
      'timetz' => 'timeTz',
      'tinyinteger' => 'tinyInteger',
      'tinyint' => 'tinyInteger',
      'timestamp' => 'timestamp',
      'timestamptz' => 'timestampTz',
      'unsignedbiginteger' => 'unsignedBigInteger',
      'unsignedbigint' => 'unsignedBigInteger',
      'unsignedInteger' => 'unsignedInteger',
      'unsignedint' => 'unsignedInteger',
      'unsignedmediuminteger' => 'unsignedMediumInteger',
      'unsignedmediumint' => 'unsignedMediumInteger',
      'unsignedsmallinteger' => 'unsignedSmallInteger',
      'unsignedsmallint' => 'unsignedSmallInteger',
      'unsignedtinyinteger' => 'unsignedTinyInteger',
      'uuid' => 'uuid',
    ),
    'eloquent_type_to_html_type' => 
    array (
      'char' => 'text',
      'date' => 'text',
      'dateTime' => 'text',
      'dateTimeTz' => 'text',
      'bigIncrements' => 'number',
      'binary' => 'textarea',
      'boolean' => 'checkbox',
      'decimal' => 'number',
      'double' => 'number',
      'enum' => 'select',
      'float' => 'number',
      'integer' => 'number',
      'ipAddress' => 'text',
      'json' => 'checkbox',
      'jsonb' => 'checkbox',
      'longText' => 'textarea',
      'macAddress' => 'text',
      'mediumInteger' => 'number',
      'mediumText' => 'textarea',
      'string' => 'text',
      'text' => 'textarea',
      'time' => 'text',
      'timeTz' => 'text',
      'tinyInteger' => 'number',
      'timestamp' => 'text',
      'timestampTz' => 'text',
      'unsignedBigInteger' => 'number',
      'unsignedInteger' => 'number',
      'unsignedMediumInteger' => 'number',
      'unsignedSmallInteger' => 'number',
      'unsignedTinyInteger' => 'number',
      'uuid' => 'text',
    ),
  ),
  'codegenerator_custom' => 
  array (
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'database' => 'tms',
        'prefix' => '',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'tms',
        'username' => 'root',
        'password' => NULL,
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'strict' => true,
        'engine' => NULL,
        'modes' => 
        array (
          0 => 'STRICT_TRANS_TABLES',
          1 => 'NO_ZERO_IN_DATE',
          2 => 'NO_ZERO_DATE',
          3 => 'ERROR_FOR_DIVISION_BY_ZERO',
          4 => 'NO_AUTO_CREATE_USER',
          5 => 'NO_ENGINE_SUBSTITUTION',
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'tms',
        'username' => 'root',
        'password' => NULL,
        'charset' => 'utf8',
        'prefix' => '',
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'tms',
        'username' => 'root',
        'password' => NULL,
        'charset' => 'utf8',
        'prefix' => '',
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'default' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 0,
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'public',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\xampp\\htdocs\\tms\\storage\\app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\xampp\\htdocs\\tms\\storage\\app/public',
        'url' => 'http://localhost/tms/public//storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
      ),
    ),
  ),
  'mail' => 
  array (
    'driver' => 'smtp',
    'host' => 'smtp.gmail.com',
    'port' => '587',
    'from' => 
    array (
      'address' => 'developergh21@gmail.com',
      'name' => 'support@gmail.com',
    ),
    'encryption' => 'tls',
    'username' => 'developergh21@gmail.com',
    'password' => 'utqbxbstqtigcosj',
    'sendmail' => '/usr/sbin/sendmail -bs',
    'stream' => 
    array (
      'ssl' => 
      array (
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true,
      ),
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'C:\\xampp\\htdocs\\tms\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'onesignal' => 
  array (
    'app_id' => 'ONESIGNAL_APP_ID',
    'rest_api_key' => NULL,
    'user_auth_key' => NULL,
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => 'your-public-key',
        'secret' => 'your-secret-key',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
      ),
    ),
    'failed' => 
    array (
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
    'stripe' => 
    array (
      'model' => 'App\\User',
      'key' => NULL,
      'secret' => NULL,
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'C:\\xampp\\htdocs\\tms\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'tms_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
    'same_site' => NULL,
  ),
  'sweet-alert' => 
  array (
    'autoclose' => 6000,
  ),
  'trustedproxy' => 
  array (
    'proxies' => 
    array (
      0 => '192.168.1.10',
    ),
    'headers' => 
    array (
      0 => 30,
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tms\\resources\\views',
    ),
    'compiled' => 'C:\\xampp\\htdocs\\tms\\storage\\framework\\views',
  ),
  0 => 'config/sweet-alert.php',
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'dont_alias' => 
    array (
    ),
  ),
);
