# taskmanager
This project is aimed at assigning task to members in a team.

